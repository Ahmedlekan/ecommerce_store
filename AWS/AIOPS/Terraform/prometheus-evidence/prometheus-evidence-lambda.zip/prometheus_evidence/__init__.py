"""Prometheus evidence Lambda package."""
